# Tempus Dominus Bootstrap 4

Version 5 was attempt to build a core module and build other modules like bootstrap 3/4 that handled rendering. Unfortunately, due to my health and other factors you can read about on [my blog](https://eonasdan.com/posts/state-of-my-picker.html) I was unable to maintain 3 extra projects. V6 is a work in progress and is come back under the [orginial repo which as been renamed as tempus-dominus](https://github.com/Eonasdan/tempus-dominus).
