-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3306
-- Tiempo de generación: 18-05-2021 a las 20:09:36
-- Versión del servidor: 5.7.24
-- Versión de PHP: 7.2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `dbventas2021`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `boleta`
--

DROP TABLE IF EXISTS `boleta`;
CREATE TABLE IF NOT EXISTS `boleta` (
  `NUM_BOLETA` int(11) NOT NULL AUTO_INCREMENT,
  `FECHA` date NOT NULL,
  `ID_CLIENTE` char(5) NOT NULL,
  `ID_USUARIO` int(11) NOT NULL,
  PRIMARY KEY (`NUM_BOLETA`),
  KEY `ID_CLIENTE` (`ID_CLIENTE`),
  KEY `ID_USUARIO` (`ID_USUARIO`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `boleta`
--

INSERT INTO `boleta` (`NUM_BOLETA`, `FECHA`, `ID_CLIENTE`, `ID_USUARIO`) VALUES
(1, '2015-01-10', 'C0011', 1),
(2, '2015-01-20', 'C0002', 1),
(3, '2015-01-20', 'C0001', 1),
(4, '2015-01-23', 'C0005', 1),
(5, '2015-02-10', 'C0001', 1),
(6, '2015-02-20', 'C0002', 1),
(7, '2015-03-05', 'C0006', 1),
(8, '2015-03-24', 'C0006', 1),
(9, '2015-04-20', 'C0005', 1),
(10, '2015-04-20', 'C0011', 1),
(11, '2015-05-10', 'C0006', 1),
(12, '2015-06-20', 'C0006', 1),
(13, '2015-07-20', 'C0001', 1),
(14, '2015-07-26', 'C0006', 1),
(15, '2015-07-20', 'C0006', 1),
(16, '2015-07-20', 'C0005', 1),
(17, '2015-08-10', 'C0002', 1),
(18, '2015-09-05', 'C0012', 1),
(19, '2015-10-20', 'C0006', 1),
(20, '2015-11-27', 'C0014', 1),
(21, '2015-11-05', 'C0002', 1),
(22, '2015-11-20', 'C0001', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

DROP TABLE IF EXISTS `cliente`;
CREATE TABLE IF NOT EXISTS `cliente` (
  `ID_CLIENTE` char(5) NOT NULL,
  `NOMBRES` varchar(30) NOT NULL,
  `PATERNO` varchar(30) NOT NULL,
  `MATERNO` varchar(30) NOT NULL,
  `DIRECCION` varchar(40) DEFAULT NULL,
  `FONO` char(15) DEFAULT NULL,
  `ID_DISTRITO` char(3) NOT NULL,
  `EMAIL` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID_CLIENTE`),
  KEY `ID_DISTRITO` (`ID_DISTRITO`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `cliente`
--

INSERT INTO `cliente` (`ID_CLIENTE`, `NOMBRES`, `PATERNO`, `MATERNO`, `DIRECCION`, `FONO`, `ID_DISTRITO`, `EMAIL`) VALUES
('C0001', 'CARLOS', 'LOPEZ', 'HURTADO', 'Calle El Pino 346', '4677352', 'L01', 'clopez@hotmail.com'),
('C0002', 'FRIDA', 'QUIROZ', 'DUARTE', 'Jr. Los Reyes 475 ', '6734732', 'L06', 'fquiroz@peru.com'),
('C0003', 'ALEJANDRO', 'TRAUCO', 'MANRIQUE', 'Jr.Huascar 956', '4676732', 'L04', 'atruco@gmail.com'),
('C0004', 'CARLA', 'BLANCO', 'RUIZ', 'Av. Arequipa 451', '4867438', 'L03', 'cblanco@hotmail.com'),
('C0005', 'CORINA', 'MENDOZA', 'PEREZ', 'Av. Ingenierios 111', '2548965', 'L09', 'cmendoza@hotmail.com'),
('C0006', 'JORGE', 'RODAS', 'DIONICIO', 'Jr. Las Liras 456', '4789658', 'L03', 'jrodas@gmail.com'),
('C0007', 'ORLANDO', 'CUEVAS', 'CABANILLAS', 'Calle La Encantada 425', '5698532', 'L11', 'ocuevas@peru.com'),
('C0008', 'ANTUANE', 'RODRIGUEZ', 'ALARCON', 'Av. Dorado 347', '4589732', 'L05', 'arodriguez@hotmail.com'),
('C0009', 'MANUEL', 'SUAREZ', 'FERNANDEZ', 'Jr. Los Robles 854', '4576738', 'L19', 'msuarez@gmail.com'),
('C0010', 'JUAN', 'GUTIERREZ', 'DIAZ', 'Calle Girasoles 456', '4897421', 'L14', 'jgutierrez@hotmail.com'),
('C0011', 'CARLOS', 'COLAN', 'BARDALES', 'Av. Los Héroes 895', '3698574', 'L19', 'ccolan@peru.com'),
('C0012', 'MARTIN', 'CARRILLO', 'SALAS', 'Calle Los Huertos 844', '8965952', 'L08', 'mcarrillo@gmail.com'),
('C0013', 'JOSE', 'LAZARTE', 'LUJAN', 'Jr. Agapito 452', '1258965', 'L17', 'jlazarte@gmail.com'),
('C0014', 'VIDAL', 'ZORRILLA', 'RODRIGUEZ', 'Av. Héroes del cenepa 635', '1547894', 'L20', 'vzorrilla@hotmail.com'),
('C0015', 'GUILLERMO', 'RAMOS', 'FLORES', 'Jr. Las Almendras 211', '4587964', 'L03', 'gramos@gmail.com'),
('C0016', 'LEWIS', 'VALENZUELA', 'ALEGRIA', 'Calle Lima 168', '979783499', 'L23', 'lewisvalenzuela@hotmail.com'),
('C0017', 'JUAN', 'CHOCNE ', 'PEDROZI', 'CALLE MATTA 7000', '765438', 'L10', 'juan@hotmail.com');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalleboleta`
--

DROP TABLE IF EXISTS `detalleboleta`;
CREATE TABLE IF NOT EXISTS `detalleboleta` (
  `NUM_BOLETA` int(11) NOT NULL,
  `ID_PRODUCTO` char(5) NOT NULL,
  `CANTIDAD` int(11) NOT NULL,
  PRIMARY KEY (`NUM_BOLETA`,`ID_PRODUCTO`),
  KEY `ID_PRODUCTO` (`ID_PRODUCTO`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `detalleboleta`
--

INSERT INTO `detalleboleta` (`NUM_BOLETA`, `ID_PRODUCTO`, `CANTIDAD`) VALUES
(1, 'P0005', 10),
(1, 'P0001', 20),
(2, 'P0002', 20),
(2, 'P0005', 10),
(2, 'P0003', 15),
(3, 'P0005', 19),
(4, 'P0001', 19),
(4, 'P0005', 15),
(4, 'P0003', 11),
(5, 'P0002', 15),
(5, 'P0005', 10),
(6, 'P0003', 19),
(7, 'P0002', 11),
(8, 'P0001', 10),
(9, 'P0005', 11),
(10, 'P0015', 12),
(11, 'P0002', 11),
(11, 'P0005', 15),
(12, 'P0003', 19),
(12, 'P0015', 15),
(13, 'P0005', 11),
(13, 'P0002', 12),
(14, 'P0005', 19),
(15, 'P0003', 12),
(16, 'P0015', 15),
(17, 'P0001', 21),
(18, 'P0005', 21),
(18, 'P0004', 12),
(19, 'P0004', 15),
(20, 'P0015', 30),
(21, 'P0005', 30),
(22, 'P0001', 30);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `distrito`
--

DROP TABLE IF EXISTS `distrito`;
CREATE TABLE IF NOT EXISTS `distrito` (
  `ID_DISTRITO` char(3) NOT NULL,
  `DESCRIPCION` varchar(50) NOT NULL,
  PRIMARY KEY (`ID_DISTRITO`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `distrito`
--

INSERT INTO `distrito` (`ID_DISTRITO`, `DESCRIPCION`) VALUES
('L01', 'CERCADO'),
('L02', 'ANCON'),
('L03', 'ATE'),
('L04', 'BARRANCO'),
('L05', 'BREÑA'),
('L06', 'CARABAYLLO'),
('L07', 'COMAS'),
('L08', 'CHACLACAYO'),
('L09', 'CHORRILLOS'),
('L10', 'EL AGUSTINO'),
('L11', 'JESUS MARIA'),
('L12', 'LA MOLINA'),
('L13', 'LA VICTORIA'),
('L14', 'LINCE'),
('L15', 'LURIGANCHO'),
('L16', 'LURIN'),
('L17', 'MAGDALENA'),
('L18', 'MIRAFLORES'),
('L19', 'PACHACAMAC'),
('L20', 'PUCUSANA'),
('L21', 'SAN MIGUEL'),
('L22', 'VISTA ALEGRE'),
('L23', 'NASCA'),
('', ''),
('L24', 'palpa'),
('L25', 'marcona'),
('L29', 'NASCA127777'),
('L27', 'NASCA13'),
('L28', 'orcona');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

DROP TABLE IF EXISTS `producto`;
CREATE TABLE IF NOT EXISTS `producto` (
  `ID_PRODUCTO` char(5) NOT NULL,
  `DESCRIPCION` varchar(50) NOT NULL,
  `PRECIO` decimal(8,2) NOT NULL,
  `STOCK` int(11) NOT NULL,
  `FECHA_VENC` date DEFAULT NULL,
  PRIMARY KEY (`ID_PRODUCTO`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `producto`
--

INSERT INTO `producto` (`ID_PRODUCTO`, `DESCRIPCION`, `PRECIO`, `STOCK`, `FECHA_VENC`) VALUES
('P0001', 'PYE DE MANZANA', '20.00', 500, '2015-05-14'),
('P0002', 'TORTA DE CHOCOLATE', '45.00', 100, '2015-07-04'),
('P0003', 'TORTA TRES LECHES', '30.00', 40, '2015-06-24'),
('P0004', 'MOUSE DE MANZANA', '35.00', 70, '2015-09-06'),
('P0005', 'ARROZ CON LECHE-ENVASE ESPECIAL', '13.00', 40, '2015-11-04'),
('P0006', 'MAZAMORRA MORADA', '1.50', 70, '2015-12-04'),
('P0007', 'YOGURT ARABE', '3.00', 100, '2015-05-04'),
('P0008', 'PAN CON POLLO', '2.00', 500, '2015-06-05'),
('P0009', 'BROWNIE', '3.00', 300, '2015-05-04'),
('P0010', 'BESO DE MOZA', '1.00', 400, '2015-06-03'),
('P0011', 'PYE DE LIMON', '1.70', 100, '2015-05-02'),
('P0012', 'TORTA DE NARANJA', '16.00', 10, '2015-04-07'),
('P0013', 'TORTA DE FRESA', '41.00', 100, '2015-05-07'),
('P0014', 'ALFAJORES', '0.30', 400, '2015-04-06'),
('P0015', 'CHOCOTEJAS', '2.00', 100, '2015-04-14'),
('P0016', 'SUSPIRO A LA LIMEÑA', '3.50', 100, '2015-06-12'),
('P0017', 'MERMELADA', '3.00', 10, '2022-06-03'),
('P0018', 'MANTEQUILLA', '2.50', 60, '2021-09-30'),
('P0019', 'SALVADO DE TRIGO', '5.00', 12, '2022-01-06');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

DROP TABLE IF EXISTS `usuario`;
CREATE TABLE IF NOT EXISTS `usuario` (
  `ID_USUARIO` int(11) NOT NULL AUTO_INCREMENT,
  `NOMBRES` varchar(30) NOT NULL,
  `PATERNO` varchar(30) NOT NULL,
  `MATERNO` varchar(30) NOT NULL,
  `DNI` varchar(15) NOT NULL,
  `DIRECCION` varchar(40) NOT NULL,
  `CELULAR` varchar(15) NOT NULL,
  `EMAIL` varchar(50) NOT NULL,
  `PASSWORD` varchar(200) NOT NULL,
  `TIPO` enum('GERENCIA','VENTAS') NOT NULL,
  PRIMARY KEY (`ID_USUARIO`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`ID_USUARIO`, `NOMBRES`, `PATERNO`, `MATERNO`, `DNI`, `DIRECCION`, `CELULAR`, `EMAIL`, `PASSWORD`, `TIPO`) VALUES
(1, 'JUAN', 'CHOCNE', 'PODOLSKY', '54321894', 'CALLE LIMA 560', '987456321', 'juan@hotmail.com', 'c1a14d6139aee67b520c766321bd894d', 'GERENCIA');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
